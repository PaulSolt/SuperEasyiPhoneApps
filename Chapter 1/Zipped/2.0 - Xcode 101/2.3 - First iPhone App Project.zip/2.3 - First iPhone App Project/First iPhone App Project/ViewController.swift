//
//  ViewController.swift
//  First iPhone App Project
//
//  Created by Paul Solt on 10/26/15.
//  Copyright © 2015 Paul Solt. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        print("Hi Paul Solt")
    }

}


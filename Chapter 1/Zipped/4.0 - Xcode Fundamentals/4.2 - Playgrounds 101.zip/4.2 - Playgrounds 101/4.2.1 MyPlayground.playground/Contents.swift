//: Playground - noun: a place where people can play

import UIKit

let name = "Paul Solt"

// use let instead of var

var name2 = "Paul Smith"

print(name)

// Homework: copy and paste code into iPhone app viewDidLoad:

let age = 29
let favoriteColor = UIColor.blueColor() // .blackColor()



